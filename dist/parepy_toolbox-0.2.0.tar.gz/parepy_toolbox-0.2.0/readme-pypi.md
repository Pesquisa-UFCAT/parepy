# PAREpy Toolbox

**Probabilistic Approach to Reliability Engineering**  
Version: _0.2.0_

[website](https://wmpjrufg.github.io/PAREPY/)